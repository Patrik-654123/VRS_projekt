#include "stm32f3xx_hal.h"
#include "stdbool.h"
#include "stdio.h"
#include "stdlib.h"

// definovanie hranicnych hodnot
#define LEN 20
#define MAX_VAL 1000
#define MIN_DIF 250
#define COV_VAL 1    // all sensors are completely covered

// definovanie pouzitych funkcii
bool gestureRecognition(uint16_t *ptrData, uint8_t length, uint16_t *const ptrDataStart);
void createMessage(char* messageHeader, uint16_t* messageBody);
uint16_t minimalHeight(uint16_t *gesture, uint16_t len);
void liveByte();
