#include "gesture.h"
#include "stdbool.h"
#include "stdio.h"
#include "stdlib.h"
#include "stm32f3xx_hal_uart.h"
#include "usart.h"

uint16_t messageBody[4];

// funkcia na rozpoznavanie gest
bool gestureRecognition(uint16_t *ptrData, uint8_t length, uint16_t *const ptrDataStart) {
	uint16_t gesture[4][length];
	uint16_t *ptrGest = ptrData;
	static uint16_t nominalHeightVal = 0;

	for (int8_t i = length - 1; i >= 0; i--) {
		gesture[0][i] = *ptrGest;
		gesture[1][i] = *(ptrGest + LEN);
		gesture[2][i] = *(ptrGest + 2*LEN);
		gesture[3][i] = *(ptrGest + 3*LEN);
		if (ptrGest == ptrDataStart) {
			ptrGest = ptrDataStart + LEN - 1;
		}
		else
			ptrGest--;
	}

	// vyhodnocovanie podmienok na zaklade dat zo senzorov
	bool rightIn = (gesture[3][0] + MIN_DIF < gesture[0][0]) || (gesture[2][0] + gesture[3][0] + MIN_DIF < gesture[0][0] + gesture[1][0]);
	bool leftIn = (gesture[0][0] + MIN_DIF < gesture[3][0]) || (gesture[0][0] + gesture[1][0] + MIN_DIF < gesture[2][0] + gesture[3][0]);
	bool rightOut = false;
	bool leftOut = false;
	if (length >= 4) {
		leftOut = (gesture[0][length-4] + MIN_DIF < gesture[3][length-4]) || (gesture[0][length-4] + gesture[1][length-4] + MIN_DIF < gesture[2][length-4] + gesture[3][length-4]);
		rightOut = (gesture[3][length-4] + MIN_DIF < gesture[0][length-4]) || (gesture[2][length-4] + gesture[3][length-4] + MIN_DIF < gesture[0][length-4] + gesture[1][length-4]);
	}
	bool covered = (gesture[0][length-1] < COV_VAL) && (gesture[1][length-1] < COV_VAL) && (gesture[2][length-1] < COV_VAL) && (gesture[3][length-1] < COV_VAL);
	bool nominalHeight = ((gesture[0][length-1] < MAX_VAL) || (gesture[1][length-1] < MAX_VAL) || (gesture[2][length-1] < MAX_VAL) || (gesture[3][length-1] < MAX_VAL)) && !covered;

	static bool wasNominalHeight;
	static int16_t oldYdifference = 0;
	static int16_t oldXdifference = 0;
	int16_t Ydifference = 5;
	uint16_t minHeight = 0;

	// po opusteni nominalnej vysky
	if(!nominalHeight) {

		if (wasNominalHeight) {
			messageBody[0] = 3; messageBody[1] = 5; messageBody[2] = 0;
			createMessage("CMD",messageBody);
		}

		wasNominalHeight = false;
		nominalHeightVal = 0;
	}

	// nominalna vyska
	if (nominalHeight) {

		minHeight = minimalHeight(&gesture[0][length-1], length);

		if (nominalHeightVal == 0)
			nominalHeightVal =  minHeight;

		Ydifference = ((int16_t)minHeight - (int16_t) nominalHeightVal)/40 + 5 < 0 ? 0 : (int16_t)(minHeight - nominalHeightVal)/40 + 5;
		Ydifference = Ydifference > 10 ? 10 : Ydifference;

		static int16_t Xdifference = 3;

		uint16_t right3Sum = gesture[1][length-1] + gesture[2][length-1] + gesture[3][length-1];
		uint16_t left3Sum = gesture[0][length-1] + gesture[1][length-1] + gesture[2][length-1] ;


		int16_t sumDifference = (int16_t)right3Sum - (int16_t)left3Sum;

		//go left
		if (sumDifference > 200 ) {

			Xdifference = 2;

			if (sumDifference > 1000) {
				Xdifference = 1;

				if (sumDifference > 2000)
					Xdifference = 0;
			}
		//go right
		} else if (sumDifference < -200 ) {

			Xdifference = 4;

			if (sumDifference < -1000) {
				Xdifference = 5;

				if (sumDifference < -2000)
					Xdifference = 6;
			}
		} else {

			Xdifference = 3;
		}

		// zamedzenie sucasneho pohybu
		if(Xdifference != 3)
			Ydifference = 5;

		if (Ydifference != 5)
			Xdifference = 3;

		// pri zmene pozadovanej rychlosti kurzora posli prikaz
		if((oldYdifference != Ydifference) || (oldXdifference != Xdifference)) {
			messageBody[0] = Xdifference; messageBody[1] = Ydifference; messageBody[2] = 5;
			createMessage("CMD",messageBody);
		}

		oldYdifference = Ydifference;
		oldXdifference = Xdifference;
		wasNominalHeight = true;
	}

	// prepnutie modu
	else if (covered) {
		messageBody[0] = 0; messageBody[1] = 0; messageBody[2] = 2;
		createMessage("CMD",messageBody);
	}

	//
	else if (rightIn) {   // RIGHT -> LEFT
		ptrGest = &gesture[0][length-1];
		do  {
			ptrGest--;
		} while ((*ptrGest > MAX_VAL) && (*(ptrGest + length) > MAX_VAL) &&
				(*(ptrGest + 2*length) > MAX_VAL) && (*(ptrGest + 3*length) > MAX_VAL));

		// gesto na sipku dolava
		if ((*ptrGest + MIN_DIF < *(ptrGest + 3*length)) ||
				(*ptrGest + *(ptrGest + length) + MIN_DIF < *(ptrGest + 2*length) + *(ptrGest + 3*length))) {
			messageBody[0] = 0; messageBody[1] = 0; messageBody[2] = 3;
			createMessage("CMD",messageBody);
		}

		// gesto na pravy klik mysou
		else if (rightOut) {    // rightIn -> rightOut
			messageBody[0] = 0; messageBody[1] = 0; messageBody[2] = 6;
			createMessage("CMD",messageBody);
		}
	}

	else if (leftIn) {   // LEFT -> RIGHT
		ptrGest = &gesture[0][length-1];
		do  {
			ptrGest--;
		} while ((*ptrGest > MAX_VAL) && (*(ptrGest + length) > MAX_VAL) && (*(ptrGest + 2*length) > MAX_VAL) && (*(ptrGest + 3*length) > MAX_VAL));

		// gesto na sipku doprava
		if ((*(ptrGest + 3*length) + MIN_DIF < *ptrGest) || (*(ptrGest + 2*length) + *(ptrGest + 3*length) + MIN_DIF < *ptrGest + *(ptrGest + length))) {
			messageBody[0] = 0; messageBody[1] = 0; messageBody[2] = 4;
			createMessage("CMD",messageBody);
		}

		// gesto na lavy klik mysou
		else if (leftOut) {    // leftIn -> leftOut
			messageBody[0] = 0; messageBody[1] = 0; messageBody[2] = 7;
			createMessage("CMD",messageBody);
		}
	}

	return nominalHeight;
}


/* FUNKCIA NA VYTVORENIE SPRAVY NA POSLANIE CEZ UART
uint16_t messageBody[4];

messageBody[0] = bInt;
createMessage("B",messageBody);

messageBody[0] = bMessage; messageBody[1] = bMessage + 10; messageBody[2] = bMessage + 20; messageBody[3] = bMessage + 30;
createMessage("D",messageBody);

messageBody[0] = 0; messageBody[1] = 0; messageBody[2] = 0;
createMessage("CMD",messageBody);
*/
void createMessage(char* messageHeader, uint16_t* messageBody)
{
	uint8_t numOfCycles = 0;

	if(strcmp(messageHeader,"D") == 0) {
		numOfCycles = 4;
	}
	else if(strcmp(messageHeader,"CMD") == 0) {
		numOfCycles = 3;
		messageBody[0] = messageBody[0];
		messageBody[1] = messageBody[1];
	}
	else if(strcmp(messageHeader,"B") == 0) {
		numOfCycles = 1;
	}

	char message[30];
	memset(message,'\0',30);
	char messageBodyStr[4][5];

	strcat(message,"-");
	strcat(message,messageHeader);

	for(int i = 0; i < numOfCycles;i++)
	{
		strcat(message,"_");
		sprintf(messageBodyStr[i],"%d",messageBody[i]);
		strcat(message,messageBodyStr[i]);
	}

	strcat(message,"%");

	HAL_HalfDuplex_EnableTransmitter(&huart1);
	HAL_UART_Transmit(&huart1, &message, strlen((const char*)message), 50);
	HAL_HalfDuplex_EnableReceiver(&huart1);
}

// urcenie minimalnej vysky zo 4 senzorov
uint16_t minimalHeight(uint16_t *gesture, uint16_t len){

	uint16_t min =*(gesture);

	if (*(gesture + len) < min)
		min = *(gesture + len);
	if (*(gesture + 2*len) < min)
		min = *(gesture + 2*len);
	if (*(gesture + 3*len) < min)
		min = *(gesture + 3*len);

	return min;
}

// ZATIAL NEVIEME
void liveByte() {
	static uint16_t bInt = 0;

	bInt >= 255 ? bInt = 0 : bInt++;
	createMessage("B",&bInt);
}
